package com.auth.auth_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthManagementSystemApplication.class, args);
	}

}
