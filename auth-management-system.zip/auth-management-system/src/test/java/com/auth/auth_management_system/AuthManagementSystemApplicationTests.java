package com.auth.auth_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
